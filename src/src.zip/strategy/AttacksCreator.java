package strategy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import bot.BotState;
import map.Region;
import map.SuperRegion;
import move.AttackAnalyzer;
import move.AttackTransferMove;

public class AttacksCreator {
	// Starea curenta a jocului
	private BotState state;
	
	// Ponderea deschiderii fata de bonus
	private static final double magicPonder = 0.6d;
	
	public AttacksCreator(BotState state) {
		this.state = state;
	}
	
	/**
	 * TODO: vezi ca daca e de castigat repede nu mai are prioritate explorarea ci atacul!
	 *  adica daca mai e o regiune care o pot lua si un inamic langa pe care il pot cucerii, ia inamicul
	 * @return
	 */
	public ArrayList<AttackTransferMove> getAttackMoves() {
		System.err.println("Round number: " + state.getRoundNumber());
		
		computeGoForBonus();
		computeExpand();		
		computeAttackEnemy();
		
		return state.attackTransferMoves;
	}
	
	public void computeGoForBonus() {
		/**
		 * Ar trebui sa aiba prioritate regiunile din super-regiunile cu bonus maxim
		 * si pe care le poate cucerii in numar minim de pasi.
		 * Ma extind cu regiunile de pe bordura care au doar zone neutre in jur
		 * si cuceresc acele regiuni care fac parte din aceasi super-regiune
		 */
		
		for(Region region : state.getStateAnalyzer().getMyBorderRegions()) { // getMyBorderRegionsWithNeutrals()
			// Nu am cu ce sa plec de pe regiunea asta
			if(region.getArmies() <= 1)
				continue;
			
			// Vecinii din aceasi super-regiune
			for(Region superRegionNeighbor : region.getSuperRegionNeighbors()) {
				// nu transfer, doar atac regiuni
				
				// Verificare sa nu exista toRegion identic cu superRegionNeighbor in state.attackTransferMoves();
				if(existsAttackTo(superRegionNeighbor)) {
					continue;
				}
									
				if(!superRegionNeighbor.isNeutral()) {
					continue;
				}
				
				if(region.getArmies() <= 1) {
					break;
				}
				
				// Daca regiunea pe care o vreau sa o cuceresc are din start mai 
				// multa armata ca mine, nu are sens sa analizez atacul
				if(superRegionNeighbor.getArmies() >= region.getArmies()) {
					continue;
				}
				
				// Generez miscarea de atac
				AttackTransferMove attackMove = new AttackTransferMove(state.getMyPlayerName(), region, superRegionNeighbor);
				
				// Verifica daca se poate cuceri cu un numar minim de calareti
				// Daca da, atunci cucereste cu ei
				if(AttackAnalyzer.canConquereWithMinNumberOfAttackers(attackMove)) {					
					// Daca eu nu am inamic langa, dar regiunea pe care ma voi extinde are - ma mut cu toata armata
					if(!region.hasEnemiesAround(state) && superRegionNeighbor.hasEnemiesAround(state)) {
						attackMove.setArmiesToMax();
					}
					
					// Daca am inamic langa mine, si ma poate cucerii dupa ce atac regiunea pentru bonus
					// atunci nu mai atac. Mai bine o las pe aparare.
					if(region.hasEnemiesAround(state)) {
						int enemyArmies = region.getNoOfEnemyArmiesAround(state.getOpponentPlayerName());

						// Armata cu care voi ramane daca voi cuceri regiunea vecina
						int armiesLeft = region.getArmies() - attackMove.getArmies();

						// Verific sa vad daca pot fi cucerit de toate regiunile inamicului intr-un atac succesiv
						if(AttackAnalyzer.canIBeConquered(armiesLeft, enemyArmies))
							continue;
					}					
						
					state.attackTransferMoves.add(attackMove);
					region.setArmies(region.getArmies() - attackMove.getArmies());
				}
			}			
		}
	}
	
	public void computeExpand() {		
		for(Region region : state.getStateAnalyzer().getMyBorderRegions()) {
			System.err.println("De pe regiunea: " + region.getId());
			// Nu am cu ce sa plec de pe regiunea asta
			if(region.getArmies() <= 1)
				continue;
			
			// Ma extind cucerind mai intai acele super-regiuni care au bonusul maxim!
			// magicValue = bonus * (1 - R) + deschidere * R, R = 0.6
			// Sortare dupa valoarea magica
			
			// Deschiderea regiunii fata re super-regiune
			// latime de drum
			Map<SuperRegion, Integer> pathWidth = new HashMap<>();
			for(Region neighbor : region.getNeighbors()) {
				// Super-regiunea din care face parte vecinul
				SuperRegion superRegion = neighbor.getSuperRegion();
				
				// Daca nu am mai pus aceasta super-regiune, pune-o cu deschidere 1
				if(!pathWidth.containsKey(superRegion)) {
					pathWidth.put(superRegion, 1);
					continue;	
				}
				
				// Daca a mai fost gasita aceasta regiune, incrementeaza numarul de deschideri
				pathWidth.put(superRegion, pathWidth.get(superRegion) + 1);
			}
			
			// Acum am pentru aceasta regiune super-regiunile in care ma pot duce
			// Dar si prin cate regiuni ma pot duce deodata catre o super-regiune
			
			// Sortez descrescator dupa valoarea magica
			Collections.sort(region.getNeighbors(), new Comparator<Region>() {
				public int compare(Region o1, Region o2) {
					Double magicValue1 = calculateMagicValue(o1, pathWidth.get(o1.getSuperRegion()));
					Double magicValue2 = calculateMagicValue(o2, pathWidth.get(o2.getSuperRegion()));
					
					return magicValue2.compareTo(magicValue1);
				}				
			});
			
			for(Region neighbor : region.getNeighbors()) {				
				// nu transfer, doar atac regiuni
				// SA NU MAI ATAC SUPER_REGIUNEA DACA ASTA S_A FACUT ANTERIOR
				// Verificare sa nu exista toRegion identic cu superRegionNeighbor in state.attackTransferMoves();
				if(existsAttackTo(neighbor))
					continue;				

				// Doar ma extind. Nu atac inamici.
				if(!neighbor.isNeutral())
					continue;
				
				if(region.getArmies() <= 1)
					break;
				
				// Daca regiunea pe care o vreau sa o cuceresc are din start mai 
				// multa armata ca mine, nu are sens sa analizez atacul
				if(neighbor.getArmies() >= region.getArmies())
					continue;
				
				// Generez miscarea de atac
				AttackTransferMove attackMove = new AttackTransferMove(state.getMyPlayerName(), region, neighbor);
				
				// Verifica daca se poate cuceri cu un numar minim de calareti
				// Daca da, atunci cucereste cu ei
				if(AttackAnalyzer.canConquereWithMinNumberOfAttackers(attackMove)) {
					// Daca am inamic langa mine, si ma poate cucerii dupa ce atac regiunea pentru extindere
					// atunci nu ma mai extind. Mai bine o las pe aparare.
					if(region.hasEnemiesAround(state)) {
						int enemyArmies = region.getNoOfEnemyArmiesAround(state.getOpponentPlayerName());

						// Armata cu care voi ramane daca voi cuceri regiunea vecina
						int armiesLeft = region.getArmies() - attackMove.getArmies();

						// Verific sa vad daca pot fi cucerit de toate regiunile inamicului intr-un atac succesiv
						if(AttackAnalyzer.canIBeConquered(armiesLeft, enemyArmies))
							continue;
					}		
					
					state.attackTransferMoves.add(attackMove);
					region.setArmies(region.getArmies() - attackMove.getArmies());
				}
			}
			
		}
	}
	
	/**
	 * 
	 * @param toRegion
	 * @return True daca in lista de atacuri mai exista adaugat un atac
	 * catre regiunea toRegion
	 */
	public boolean existsAttackTo(Region toRegion) {
		for(AttackTransferMove move : state.attackTransferMoves)
			if(move.getToRegion().getId() == toRegion.getId())
				return true;
		
		return false;
	}
	
	/**
	 * TODO: Atac cumulat cu numar minim de armata - mai multe regiuni vecine inamice
	 */
	public void computeAttackEnemy() {
		
		// Atac (daca se poate) mai intai cu regiunile care au un numar minim de armate inamice in jur
		Collections.sort(state.getStateAnalyzer().getMyBorderRegionsWithEnemy(), new Comparator<Region>() {
			@Override
			public int compare(Region o1, Region o2) {
				return o1.getNoOfEnemyArmiesAround(state.getOpponentPlayerName()) - o2.getNoOfEnemyArmiesAround(state.getOpponentPlayerName());
			}
		});
		
		for(Region region : state.getStateAnalyzer().getMyBorderRegionsWithEnemy()) {			
			if(region.getArmies() <= 1)
				continue;
			
			// Regiunile inamice din jur
			List<Region> enemiesAround = region.getEnemiesAround(state.getOpponentPlayerName());
			
			// Atac mai intai regiunile inamice cu numar minim de armate
			Collections.sort(enemiesAround, new Comparator<Region>() {
				@Override
				public int compare(Region o1, Region o2) {
					return o1.getNoOfEnemyArmiesAround(state.getOpponentPlayerName()) - o2.getNoOfEnemyArmiesAround(state.getOpponentPlayerName());
				}
			});
			
			for(Region enemy : enemiesAround) {				
				if(region.getArmies() <= 1) {
					break;
				}
				
				// Daca regiunea pe care o vreau sa o cuceresc are din start mai 
				// multa armata ca mine, nu are sens sa analizez atacul
				if(enemy.getArmies() >= region.getArmies())
					continue;
				
				// Generez miscarea de atac
				AttackTransferMove attackMove = new AttackTransferMove(state.getMyPlayerName(), region, enemy);
				
				// Verifica daca se poate cuceri cu un numar minim de calareti
				// Daca da, atunci cucereste cu ei
				if(AttackAnalyzer.canConquereWithMinNumberOfAttackers(attackMove, 0.4)) {
					// Daca eu am un singur inamic langa mine, ma duc cu toata armata
					if(enemiesAround.size() == 1)
						attackMove.setArmiesToMax();
					
					state.attackTransferMoves.add(attackMove);
					region.setArmies(region.getArmies() - attackMove.getArmies());
				}
			}
		}
		
		// Incerc sa vad daca in urma unor atacuri succesive asupra regiunilor inamice
		// voi reusi sa cuceresc regiunea.
		Map<Region, ArrayList<Region>> successiveAttack = new HashMap<>();
		
		for(Region enemy : state.getStateAnalyzer().getEnemyRegions()) {
			// Atac succesiv doar inamicii care sunt singuri, adica nu au ajutoare
			if(!enemy.isAlone())
				continue;
			
			if(!successiveAttack.containsKey(enemy))
				successiveAttack.put(enemy, new ArrayList<>());
			
			for(Region region : enemy.getNeighbors()) {
				// Atac numai cu regiunile mele care se invecineaza cu inamicul
				if(!region.ownedByPlayer(state.getMyPlayerName()))
					continue;
				
				// Atac numai daca am cu ce
				if(region.getArmies() < 2)
					continue;
				
				// Adaug regiunea la succesiunea de atacuri catre acest inamic
				successiveAttack.get(enemy).add(region);
			}
		}
		
		// Atacurile directe nereusite catre toate regiunile inamice; se poate finaliza 
		// cu success daca se acumuleaza suficienta armata pentru atacuri succesive
		for(Entry<Region, ArrayList<Region>> pair: successiveAttack.entrySet()) {	
			if(pair.getValue().size() < 2)
				continue;
			
			// Atacurile succesive ce pot avea loc asupra acestui inamic
			List<AttackTransferMove> attackMoves = new ArrayList<>();
			
			for(Region attacker : pair.getValue()) {
				attackMoves.add(new AttackTransferMove(state.getMyPlayerName(), attacker, pair.getKey()));
			}
		
			// Verific sa vad daca atacurile succesive vor fi cu success
			if(AttackAnalyzer.canConquereWithSuccessiveAttacks(attackMoves)) {
				state.attackTransferMoves.addAll(attackMoves);
			}
		}
	}
	
	/**
	 * 
	 * @param region
	 * @param pathWidth
	 * @return
	 */
	public static double calculateMagicValue(Region region, int pathWidth) {
		return (region.getSuperRegion().getArmiesReward() * (1 - magicPonder) + pathWidth * magicPonder);
	}
}
